# Professional Computing quiz export

Extracted from `docs/LEARN_AFRICA_PROFESSIONAL_COMPUTING_SETUP.md`.

- 11 separate lesson quiz JSON files, one per lesson.
- Each lesson quiz has 50 questions: 20 MCQ, 15 True/False and 15 fill-in-the-blank.
- One separate course final examination JSON file has 100 questions: 40 MCQ, 30 True/False and 30 fill-in-the-blank.
- Total: 650 questions across 12 import files.

Each JSON file is a standalone `{ "quizzes": [ ... ] }` payload containing one quiz. Use LearnAfrica's instructor JSON import flow. Import lesson files into their matching lessons and the final examination into the course final-exam lesson.

The guide does not specify individual timer, attempt-limit, retry-fee or shuffle settings. Files use importer-safe defaults rather than invented values: timer disabled, attempts unrestricted, 70% pass score, no random question limit and shuffling disabled. Review these settings in the instructor editor after import.

Correct answers are included in instructor import data. LearnAfrica remains responsible for keeping answer keys hidden from students until submission.
